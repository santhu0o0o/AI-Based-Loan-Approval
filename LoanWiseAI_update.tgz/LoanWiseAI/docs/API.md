# LoanWise AI — API and Model Contract

This is the binding contract between the React frontend, the Flask API and the
trained model. Field names, values, status codes and response shapes below must
not change without updating all three.

Audience: people with no financial background. Every message is plain English,
with no jargon, and stack traces are never shown to users.

## Where things live
| Path | Contents |
|---|---|
| `data/raw/` | read-only inputs (`loan.csv` = labelled training data, 614 rows; `test.csv` = UNLABELLED, demo only) |
| `src/loanwise/ml/` | training code; `features.py` holds the custom transforms pickled inside the model |
| `artifacts/models/` | trained model and its report (written by `scripts/train_model.py`) |
| `src/loanwise/{api,services,domain,storage}/` | backend (see `docs/ARCHITECTURE.md`) |
| `frontend/` | React app, built to `frontend/dist` and served by Flask |

## Model artifact (training produces, API consumes)
- `artifacts/models/loan_model.pkl` — a joblib-dumped sklearn `Pipeline` (all preprocessing INSIDE it, incl. imputation/encoding/feature engineering).
- Any custom functions used in the pipeline live in `src/loanwise/ml/features.py` (must be importable as `loanwise.ml.features`).
- Input: pandas DataFrame with EXACTLY these columns and dataset-style values:
  - Gender: "Male" | "Female"
  - Married: "Yes" | "No"
  - Dependents: "0" | "1" | "2" | "3+"
  - Education: "Graduate" | "Not Graduate"
  - Self_Employed: "Yes" | "No"
  - ApplicantIncome: float, MONTHLY income in ₹
  - CoapplicantIncome: float, MONTHLY ₹
  - LoanAmount: float, in THOUSANDS of ₹ (dataset unit; backend divides user's ₹ amount by 1000)
  - Loan_Amount_Term: float months, one of 12,36,60,84,120,180,240,300,360,480
  - Credit_History: float 1.0 (meets guidelines / good) | 0.0 (bad)
  - Property_Area: "Urban" | "Semiurban" | "Rural"
- Output: `predict_proba(X)[:, 1]` = probability of APPROVAL (target Y→1, N→0).
- `artifacts/models/model_info.json`:
  ```json
  {
    "chosen_model": "Logistic Regression",
    "selection_metric": "...",
    "models": [{"name": "...", "accuracy": 0.0, "precision": 0.0, "recall": 0.0, "f1": 0.0, "cv_accuracy_mean": 0.0, "cv_accuracy_std": 0.0}],
    "feature_importance": [{"feature": "Credit History", "importance": 0.0}],
    "importance_method": "...",
    "dataset": {"rows": 614, "approved": 422, "rejected": 192},
    "trained_at": "ISO timestamp"
  }
  ```

## HTTP API (backend implements, frontend consumes). Flask on port 5000 (`LOANWISE_PORT`); the frontend dev server (`npm run dev`, esbuild) proxies /api → 5000.
All JSON. Field names (snake_case) for requests:
```
gender: "Male"|"Female"
married: "Yes"|"No"
dependents: "0"|"1"|"2"|"3+"
education: "Graduate"|"Not Graduate"
self_employed: "Yes"|"No"
applicant_income: number, monthly ₹, 0..10,000,000 (at least one of applicant/coapplicant income must be > 0)
coapplicant_income: number, monthly ₹, 0..10,000,000
loan_amount: number, FULL ₹ amount, 1,000..10,000,000
loan_term: number months, one of 12,36,60,84,120,180,240,300,360,480
credit_history: "good"|"bad"   (good = has repaid past loans/cards on time)
property_area: "Urban"|"Semiurban"|"Rural"
```

### POST /api/predict
- 200:
```json
{
  "ok": true,
  "approved": true,
  "verdict": "Likely Approved",
  "headline": "Great news! Your loan is likely to be approved.",
  "confidence": 0.84,
  "confidence_label": "High",
  "reasons": [{"type": "positive"|"negative"|"neutral", "text": "plain English"}],
  "warnings": ["plain English note about something we auto-fixed or found odd"],
  "guardrail_applied": false,
  "emi_estimate": 12345.0,
  "id": 17
}
```
- 422 (validation failed):
```json
{"ok": false, "errors": {"applicant_income": "Please type your monthly income using numbers only, like 25000."}, "message": "Some answers need fixing. Look for the red boxes."}
```
- 400 for malformed JSON, 500 generic: always `{"ok": false, "message": "plain English"}`.

### GET /api/history?limit=50 → `{"ok": true, "items": [{"id", "created_at", "inputs": {...request fields}, "approved", "verdict", "confidence"}]}`
### DELETE /api/history → `{"ok": true}`
### GET /api/model-info → contents of artifacts/models/model_info.json plus `{"ok": true}`
### GET /api/health → `{"ok": true, "model_loaded": true}`
### GET /api/sample → one random row from data/raw/test.csv converted into request-field format (for a "Fill example" button)

Flask also serves the built React app from `frontend/dist` (SPA fallback: any non-/api path → index.html).

### Status codes used by every `/api/*` route
| Status | When | Body |
|---|---|---|
| 200 | success | endpoint-specific, always `"ok": true` |
| 400 | body is not readable JSON / not a JSON object | `{"ok": false, "message": ...}` |
| 404 / 405 | unknown API path / wrong HTTP method | `{"ok": false, "message": ...}` |
| 413 | request body larger than `LOANWISE_MAX_REQUEST_BYTES` (32 KB) | `{"ok": false, "message": ...}` |
| 422 | validation failed (`/api/predict`) | `{"ok": false, "errors": {...}, "message": ...}` |
| 503 | model, model report or demo data not available | `{"ok": false, "message": ...}` |
| 500 | unexpected error (details are logged, never returned) | `{"ok": false, "message": ...}` |
