# LoanWise AI: Architecture

LoanWise AI estimates whether a home-loan application is likely to be approved
and explains the answer in plain English. It is a single Python package
(`src/loanwise`) that serves a JSON API and the built React app, plus an
offline training pipeline that produces the model artifact.

## Layers

Dependencies point downwards only. `domain` has no Flask, no I/O and no model
loading, so it can be unit-tested in isolation.

```
                 ┌───────────────────────────────────────────────────────────┐
  HTTP  ───────► │ loanwise.api            Flask app factory (create_app)     │
                 │   routes/predict.py     POST /api/predict                  │
                 │   routes/history.py     GET|DELETE /api/history            │
                 │   routes/meta.py        /api/health, /api/model-info,      │
                 │                         /api/sample                        │
                 │   spa.py                frontend/dist + SPA fallback       │
                 │   errors.py             exceptions → friendly JSON         │
                 │   messages.py           every HTTP-level user message      │
                 └──────────────┬────────────────────────────────────────────┘
                                │ calls
                 ┌──────────────▼────────────────────────────────────────────┐
                 │ loanwise.services                                          │
                 │   prediction_service    validate → sanitise → predict →    │
                 │                         guardrails → persist               │
                 │   model_registry        lazy, thread-safe, hot-reloading   │
                 │   sample_service        demo rows for "Fill example"       │
                 │   model_info            reads model_info.json              │
                 └───────┬──────────────────────┬──────────────────┬─────────┘
                         │                      │                  │
        ┌────────────────▼─────────┐ ┌──────────▼──────────┐ ┌─────▼─────────────┐
        │ loanwise.domain          │ │ loanwise.storage    │ │ artifacts/models/ │
        │   schemas   (fields,     │ │   history_repository│ │   loan_model.pkl  │
        │             limits)      │ │   (SQLite,          │ │   model_info.json │
        │   validation  layer 2    │ │    instance/*.db)   │ └─────▲─────────────┘
        │   sanitizer   layer 3    │ └─────────────────────┘       │ writes
        │   guardrails  rules      │                     ┌─────────┴─────────────┐
        │   messages    wording    │                     │ loanwise.ml (offline) │
        └──────────────────────────┘                     │   data, eda,          │
                                                         │   pipelines,          │
   loanwise.config  (Settings from LOANWISE_* env)       │   evaluation, train,  │
   loanwise.logging_config  (text / JSON logs)           │   sanity, features ◄──┼── imported when
                                                         └───────────────────────┘   unpickling
```

| Package | Responsibility | Depends on |
|---|---|---|
| `loanwise.config` | Immutable `Settings` from `LOANWISE_*` env vars | stdlib |
| `loanwise.domain` | Field schema, validation, sanitising, guardrails, user wording | pandas (sanitizer only) |
| `loanwise.storage` | SQLite prediction history | stdlib |
| `loanwise.services` | Use cases; model loading; demo samples | domain, storage, ml.features |
| `loanwise.api` | HTTP: routing, payload decoding, status codes, SPA serving | services, config |
| `loanwise.ml` | Training workflow; `features.py` is also needed at serve time | domain.schemas |

## Request flow: `POST /api/predict`

```
browser form (layer 1: input types, required fields, hints)
   │  JSON (or form-encoded) body, ≤ 32 KB, else 413
   ▼
api/routes/predict.py
   │  read_payload(): unreadable or not a JSON object → 400
   ▼
services/prediction_service.PredictionService.predict(payload)
   │
   ├─ domain/validation.validate_application()          LAYER 2
   │     forgiving on format ("25k", "₹ 2 lakh", "30 years", " YES ")
   │     strict on meaning (missing, negative, NaN, absurd, unknown choice)
   │     collects ALL errors → InvalidApplicationError → 422 {errors: {...}}
   │
   ├─ model_registry.get()  → None → ModelUnavailableError → 503
   │
   ├─ domain/sanitizer.to_model_frame()                  LAYER 3
   │     request fields → dataset columns, ₹ → ₹ thousands,
   │     "good"/"bad" → 1.0/0.0, typo warning for very high income
   │
   ├─ model.predict_proba(frame)[0][1]
   │     exception or non-finite → ModelPredictionError → 500 (logged)
   │
   ├─ domain/guardrails.apply_guardrails(real values, p)   RULES
   │     R1 EMI > 65 % of income        → force "Likely Rejected"
   │     R2 loan > 60 × monthly income  → force "Likely Rejected"
   │     R3 bad credit                  → negative reason, confidence ≤ 0.65
   │     R4 EMI 45–65 % of income       → "big stretch" reason
   │     never turns a rejection into an approval
   │
   └─ storage/history_repository.add()   failure is logged, id = null
   ▼
200 {ok, approved, verdict, headline, confidence, confidence_label,
     reasons[3..5], warnings[], guardrail_applied, emi_estimate, id}
```

### Why three validation layers and guardrails?

1. **Browser (layer 1)** gives instant feedback but cannot be trusted.
2. **Validation (layer 2)** is the real gate. It accepts the many ways people
   type numbers and answers, and rejects anything that changes meaning. Every
   problem is reported at once so the form can highlight all of them.
3. **Sanitizer (layer 3)** guarantees the model always receives exactly the 11
   columns, dtypes and units it was trained on.
4. **Guardrails** exist because a model trained on 614 rows can approve absurd
   requests. They use the applicant's *real* numbers and can only make the
   answer more conservative.

## Model lifecycle

```
data/raw/loan.csv ──► scripts/train_model.py (loanwise.ml.train.main)
                        ├─ EDA summary + charts → artifacts/reports/eda/*.png
                        ├─ 3 pipelines × grid search, 5-fold CV on 80 % split
                        ├─ select by CV rule, refit on 100 %
                        ├─ monotonicity check (aborts before saving on failure)
                        ├─ save artifacts/models/{loan_model.pkl, model_info.json}
                        └─ reload in a fresh interpreter (loanwise.ml.sanity)
```

`ModelRegistry` reloads the pickle whenever its modification time changes, so
retraining updates a running server without a restart. The pickle references
`loanwise.ml.features`; moving or renaming that module requires retraining.
`scikit-learn` is pinned to the exact version that produced the pickle.

## Errors and logging

* Every failure under `/api` returns `{"ok": false, "message": ...}` with a
  message from `api/messages.py`; exception text never reaches the client.
* Non-API paths fall back to the SPA (`index.html`), or a short "almost
  ready" page when the frontend has not been built.
* Library modules log via `logging.getLogger(__name__)`; entry points call
  `configure_logging()` once. Set `LOANWISE_LOG_FORMAT=json` for log shippers.

## Configuration and deployment

* All settings come from `LOANWISE_*` environment variables (see
  `src/loanwise/config.py` and `.env.example`). Paths default to locations
  inside the repository.
* Development: `make run` (Flask dev server). Production: `gunicorn wsgi:app`;
  the `Dockerfile` builds the frontend with Node, then runs gunicorn as a
  non-root user on `python:3.12-slim`.
* Prediction history is SQLite at `instance/loanwise.db`. That is fine for a
  single instance. Running several replicas needs a shared database behind the
  same `HistoryRepository` interface.

## Tests

| Suite | Scope |
|---|---|
| `tests/unit/test_validation.py` | layer 2 parsing and messages |
| `tests/unit/test_sanitizer.py` | layer 3 frame shape and units |
| `tests/unit/test_guardrails.py` | EMI maths, overrides, confidence, reasons |
| `tests/unit/test_features.py` | pipeline transforms, schema consistency, selection rule, saved-model monotonicity |
| `tests/unit/test_config.py` | env parsing, defaults, invalid values |
| `tests/unit/test_services.py` | prediction orchestration, model registry, samples, model info |
| `tests/integration/test_api.py` | HTTP behaviour with fake, broken, missing and real models; CORS; SPA |
| `tests/integration/test_history.py` | history round-trip and clearing |

Run them with `python3 -m unittest discover -s tests -t .` (or `pytest`).
